import { createContext } from "react";

//creating context

const noteContext=createContext();
export default noteContext