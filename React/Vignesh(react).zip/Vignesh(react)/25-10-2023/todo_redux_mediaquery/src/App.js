
import './App.css';
import Todo from './components/Todo';


function App() {
  return (
    <>
<Todo></Todo>

    </>
  );
}

export default App;
