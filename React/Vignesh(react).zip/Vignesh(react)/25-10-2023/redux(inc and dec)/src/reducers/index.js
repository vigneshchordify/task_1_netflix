import changeTheNumber from "./updown";
import { combineReducers } from "redux";



const rootReducer=combineReducers({

    changeTheNumber
    
    
});

export default rootReducer